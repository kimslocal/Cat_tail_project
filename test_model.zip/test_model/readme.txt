11/3일 기준 test run 성공한 model ipynb파일과 사용한 train/test 데이터

