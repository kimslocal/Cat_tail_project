# side_View > 2022-11-03 10:31pm
https://universe.roboflow.com/cattail1/side_view

Provided by a Roboflow user
License: CC BY 4.0

